package com.vishal.shopthings.data.remote.api



import android.util.Log
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.vishal.shopthings.R
import com.vishal.shopthings.ShopThings
import com.vishal.shopthings.ShopThings.Companion.gson
import com.vishal.shopthings.data.local.model.ApiResponse
import com.vishal.shopthings.util.getData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Response
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.SocketTimeoutException

abstract class ApiRequestResponse {

    suspend fun <T : Any?> apiRequest(call: suspend () -> Response<T>?): ApiResponse {
        val response = call.invoke()

        Log.d("API>>", "REQUEST>>URL>> ${gson.toJson(response?.raw()?.request?.url?.toUrl())}")
        Log.d("API>>", "REQUEST>>PARAMETERS>> ${gson.toJson(response?.raw()?.request)}")
        Log.d("API>>", "REQUEST>>CODE>> ${gson.toJson(response?.code())}")
        Log.d("API>>", "REQUEST>>RESPONSE>> ${gson.toJson(response?.body())}")
        Log.d("API>>", "REQUEST>>ERROR>> ${getData(response?.errorBody()?.charStream(), JsonObject::class.java)?.get("message")?.asString}")
        Log.d("API>>", "REQUEST>>ERROR>> ${response.toString()}")

        val apiResponse = ApiResponse()

        response?.let {

            apiResponse.statusCode = response.code()

            if (apiResponse.statusCode == 404 || apiResponse.statusCode == 400 || apiResponse.statusCode == 500 || apiResponse.statusCode == 502) {
                apiResponse.success = false
                handleErrorResponse(response, apiResponse) // Emit the error response

            } else {

                try {

                    if (response.isSuccessful && response.body() != null) {

                        if (response.code() == 200 || response.code() == 201) {

                            val jsonObject = getData(response.body(), JsonArray::class.java)
                            apiResponse.data = jsonObject
                            apiResponse.message = "Success"
                            apiResponse.success = jsonObject?.isEmpty?.not() // Emit the success response

                        } else {
                            handleNonSuccessResponse(response, apiResponse) // Emit the non-success response
                        }

                    } else {
                        handleErrorResponse(response, apiResponse) // Emit the error response
                    }

                } catch (e: Exception) {
                    handleException(e, response, apiResponse)
                }
            }
        }

        return apiResponse
    }

    private fun handleNonSuccessResponse(response: Response<*>, apiResponse: ApiResponse) {
        apiResponse.success = false
        apiResponse.message = getData(response.body(), JsonObject::class.java)?.get("message")?.asString
        Log.d("API>>", "REQUEST>>RESPONSE>>API>> $apiResponse")
    }

    private fun handleErrorResponse(response: Response<*>, apiResponse: ApiResponse) {

        when (apiResponse.statusCode) {

            400, 404 -> {

                val errorString = response.errorBody()?.byteStream()?.bufferedReader().use { it?.readText() }

                apiResponse.message = if (!errorString.isNullOrEmpty()) {
                    val jsonObjectData = gson.fromJson(errorString, JsonObject::class.java)
                    jsonObjectData.get("message").asString

                } else {
                    response.message()
                }
            }

            500 -> {
                apiResponse.message = ShopThings.currentActivity?.getString(R.string.err_something_went_wrong)
            }

            else -> {
                apiResponse.message = response.message()
            }
        }

        Log.d("API>>", "REQUEST>>RESPONSE>>API>> $apiResponse")
    }

    private fun handleException(e: Exception, response: Response<*>?, apiResponse: ApiResponse) {

        when (e) {

            is SocketTimeoutException -> {
                apiResponse.success = false
                apiResponse.message = "TIME OUT EXCEPTION"
                Log.d("API>>", "REQUEST>>RESPONSE>>API>> $apiResponse")
            }

            else -> {
                if (response?.errorBody() != null) {
                    apiResponse.success = false
                    apiResponse.message = getData(response.errorBody()?.charStream(), JsonObject::class.java)?.get("message")?.asString
                    Log.d("API>>", "REQUEST>>RESPONSE>>API>> $apiResponse")

                } else {
                    apiResponse.success = false
                    apiResponse.message = "INTERNAL SERVER ERROR"
                    Log.d("API>>", "REQUEST>>RESPONSE>>API>> $apiResponse \n e: ${e.message}")
                }
            }
        }
    }
}
