package com.vishal.shopthings.ui.activity.product

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.lifecycle.ViewModelProvider
import com.google.gson.Gson
import com.vishal.shopthings.R
import com.vishal.shopthings.data.local.model.ProductData
import com.vishal.shopthings.data.remote.api.ApiCalls
import com.vishal.shopthings.data.remote.factory.ProductViewModelFactory
import com.vishal.shopthings.data.remote.repository.ProductRepository
import com.vishal.shopthings.databinding.ActivityProductDetailsBinding
import com.vishal.shopthings.util.ExtraKey
import com.vishal.shopthings.util.FormattedAmount
import com.vishal.shopthings.util.getDataFromIntent
import com.vishal.shopthings.util.handleOnBackPressed
import com.vishal.shopthings.util.loadImage
import com.vishal.shopthings.util.request
import com.vishal.shopthings.util.setText
import com.vishal.shopthings.util.strike
import com.vishal.shopthings.util.toast
import com.vishal.shopthings.util.viewGone
import com.vishal.shopthings.util.viewVisible
import com.vishal.shopthings.viewmodel.ProductViewModel
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ProductDetailsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProductDetailsBinding
    private var strProductId: String? = null
    private lateinit var apiCall: ApiCalls
    private lateinit var productViewModel: ProductViewModel
    private var productData: ProductData? = null
    private var isBackButtonPressedToExitFromApp = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        init()
        onClicks()
        getDataFromInvokingScreen()
        setObserver()
        manageBackPressEvent()
        setToolbar()

    }

    private fun init() {
        apiCall = request(ApiCalls::class.java)
        productViewModel = ViewModelProvider(this@ProductDetailsActivity, ProductViewModelFactory(ProductRepository(apiCall)))[ProductViewModel::class.java]

    }

    private fun onClicks() {
        with(binding) {
            ivBack.setOnClickListener {
                manageBackPressEvent()
            }
        }
    }

    private fun setToolbar() {
        setText(binding.tvAppName, R.string.product_details)
    }

    private fun getDataFromInvokingScreen() {
        strProductId = getDataFromIntent(intent, ExtraKey.EXTRA_PRODUCT_ID)
        Log.e("productData>>>", "getDataFromInvokingScreen: ${Gson().toJson(strProductId)}")
        fetchProductDetailsFromDB()
    }

    private fun fetchProductDetailsFromDB() {
        if (strProductId.isNullOrEmpty().not()) {
            productViewModel.fetchAllDataOfProductByIdFromDB(strProductId!!)

        } else {
            toast("Something went wrong")
            finish()
        }
    }

    private fun setObserver() {
        productViewModel.getProductDetailsById.observe(this@ProductDetailsActivity) { productData ->

            Log.e("getProductDetailsById>>>", "setObserver: ${Gson().toJson(productData)}")
            if (productData != null) {
                this.productData = productData
                setProductDetails(productData)
            }

        }
    }

    private fun setProductDetails(productData: ProductData?) {
        with(binding) {


                // product image
                if (productData?.ProductPictures.isNullOrEmpty().not()) {
                    if (productData?.ProductPictures?.get(0)?.PictureUrl.isNullOrEmpty().not()) {
                        loadImage(ivProductLogo, productData?.ProductPictures?.get(0)?.PictureUrl, AppCompatResources.getDrawable(ivProductLogo.context, R.drawable.ic_placeholder_product))

                    } else {
                        loadImage(ivProductLogo, productData?.ProductPictures?.get(0)?.PictureUrl, AppCompatResources.getDrawable(ivProductLogo.context, R.drawable.ic_placeholder_product))
                    }

                } else {
                    loadImage(ivProductLogo, null, AppCompatResources.getDrawable(ivProductLogo.context, R.drawable.ic_placeholder_product))

                }

                // product name
                setText(tvProductName, productData?.Name ?: "-")

                //product description
                if (productData?.ShortDescription.isNullOrEmpty().not()) {
                    setText(tvProductDescription, productData?.ShortDescription)
                    viewVisible(tvProductDescription)

                } else {
                    viewGone(tvProductDescription)
                }

                // old price
                setText(tvProductOldPrice, tvProductOldPrice.context.getString(R.string.old_product_price, productData?.DiscountAmount.FormattedAmount()))
                tvProductOldPrice.strike = true

                // new price
                setText(tvProductNewPrice, tvProductNewPrice.context.getString(R.string.new_product_price, productData?.Price.FormattedAmount()))
                setText(tvProductCount, productData?.StockQuantity?.toString())

                loadImage(ivProductLogo, null, AppCompatResources.getDrawable(ivProductLogo.context, R.drawable.ic_veg))
                setText(tvProductWeight, "500gm")
            }

    }

    private fun manageBackPressEvent() {
        handleOnBackPressed {
            askForTapBackButtonAgainToExitApp()
        }
    }

    @OptIn(DelicateCoroutinesApi::class)
    private fun askForTapBackButtonAgainToExitApp() {
        if (isBackButtonPressedToExitFromApp) {
            finishAffinity()
        }

        isBackButtonPressedToExitFromApp = true

        GlobalScope.launch {
            delay(2000)
            isBackButtonPressedToExitFromApp = false
        }
    }
}