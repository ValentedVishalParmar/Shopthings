package com.vishal.shopthings.data.local.model
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.vishal.shopthings.util.Converters
import java.io.Serializable

@Entity(tableName = "product_data")
data class ProductData(
    @PrimaryKey(autoGenerate = true)
    val databaseId: Int? = null,
    val Id: Int? = null,
    val Name: String? = null,
    val ShortDescription: String? = null,
    val FullDescription: String? = null,
    val Sku: String? = null,
    val Gtin: String? = null,
    val IsGiftCard: Boolean? = false,
    val TaxRate: Int? = null,
    val ManageInventoryMethodId: Int? = null,
    val DisplayStockAvailability: Boolean? = null,
    val DisplayStockQuantity: Boolean? = null,
    var StockQuantity: Int? = 0,
    val Price: Double? = null,
    val CustomerEntersPrice: Boolean? = null,
    val MinimumCustomerEnteredPrice: Double? = null,
    val MaximumCustomerEnteredPrice: Double? = null,

    @TypeConverters(Converters::class) // Using converter for ArrayList
    var ProductPictures: List<ProductImageUrl>? = listOf(),

    @TypeConverters(Converters::class)
    var ProductFullSizePictures: List<ProductImageUrl>? = listOf(),

    var ProductCategories: String? = null,

    @TypeConverters(Converters::class)
    val ProductAttributes: List<ProductAttributes>? = listOf(),

    @TypeConverters(Converters::class)
    val ProductSpecificationAttributes: List<ProductAttributes>? = listOf(),

    val Published: Boolean? = null,
    val DisplayOrder: Int? = null,
    val ShowOnWebsite: Boolean? = null,
    val ShowOnKiosk: Boolean? = null,
    val ShowOnPosWeb: Boolean? = null,
    val ShowOnPosMobile: Boolean? = null,
    val DiscountAmount: Double? = null,
    val DiscountPercentage: Double? = null,
    val UsePercentage: Boolean? = null
) : Serializable

data class ProductAttributes(

    val Id: Int? = null,
    val ProductAttributeId: Int? = null,
    val Name: String? = null,
    val Description: String? = null,
    val TextPrompt: String? = null,
    val IsRequired: Boolean? = null,
    val DefaultValue: String? = null,
    val AllowedFileExtensions: Boolean? = null,
    val AttributeControlTypeId: Int? = null,
    val AttributeControlType: String? = null,
    @TypeConverters(Converters::class)
    val Values: List<ProductValues>? = listOf(),
    val DisplayOrder: Int? = null

) : Serializable

data class ProductImageUrl(
    val PictureUrl: String? = null,
    val DisplayOrder: Int? = null
) : Serializable

data class ProductValues(

    val Id: Int? = null,
    val Name: String? = null,
    val ColorSquaresRgb: Any? = null,
    val PriceAdjustment: Any? = null,
    val PriceAdjustmentValue: Double? = null,
    val IsPreSelected: Boolean? = null,
    val PictureUrl: Boolean? = null,
    val FullSizePictureUrl: Boolean? = null,
    val AllowOutOfStock: Boolean? = false,
    val StockQuanity: Int? = null

) : Serializable

