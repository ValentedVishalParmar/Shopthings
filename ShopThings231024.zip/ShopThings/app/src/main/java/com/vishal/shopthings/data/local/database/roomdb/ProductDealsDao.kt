package com.vishal.shopthings.data.local.database.roomdb

import androidx.room.Dao
import androidx.room.Query
import com.vishal.shopthings.data.local.model.ProductData


@Dao
interface ProductDealsDao : CommonDao<ProductData> {

    @Query("SELECT * FROM product_data WHERE databaseId = :id")
    suspend fun getProductById(id: String): ProductData

    @Query("SELECT * FROM product_data ORDER BY name ASC LIMIT :limit OFFSET :offset")
    fun getAllDataOfProductAscendingOrder(limit: Int, offset: Int): MutableList<ProductData>

    @Query("SELECT * FROM product_data ORDER BY name DESC LIMIT :limit OFFSET :offset")
    fun getAllDataOfProductDescendingOrder(limit: Int, offset: Int): MutableList<ProductData>

    @Query("SELECT COUNT(id) FROM product_data")
    fun getAllCount(): Int

    @Query("DELETE FROM product_data")
    fun nukeTable()

}


