package com.vishal.shopthings.data.remote.api

import android.content.Context
import com.vishal.shopthings.BuildConfig
import com.vishal.shopthings.ShopThings.Companion.gson
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class ApiClient(context: Context, timeOut:Long) {

    private val loggingInterceptor = HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder().connectTimeout(timeOut, TimeUnit.SECONDS)
            .writeTimeout(timeOut, TimeUnit.SECONDS)
            .readTimeout(timeOut, TimeUnit.SECONDS)
            .addInterceptor(AuthenticationInterceptor(context))
            .addInterceptor(loggingInterceptor).build()
    }

    val retrofit: Retrofit by lazy {

        Retrofit.Builder()
            .baseUrl("https://baseball-test.shopfast.com/api/v1/catalog/products/")
            .client(httpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
    }

}