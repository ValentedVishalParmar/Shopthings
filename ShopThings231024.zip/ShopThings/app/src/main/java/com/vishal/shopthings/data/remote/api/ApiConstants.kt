package com.vishal.shopthings.data.remote.api

object ApiConstants {

    /**API NAMES*/
    const val API_APP_PRODUCTS = "app-products"
    const val API_KEY_BEARER = "Bearer"




}