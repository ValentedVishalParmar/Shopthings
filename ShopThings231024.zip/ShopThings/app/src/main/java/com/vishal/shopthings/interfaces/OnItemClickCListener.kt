package com.vishal.shopthings.interfaces

interface OnItemClickCListener {
    fun onClickItem(any: Any?) {}
    fun onProductAdd(position:Int) {}
    fun onProductRemove(position:Int) {}
}