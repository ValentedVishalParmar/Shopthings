package com.vishal.shopthings.util

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.vishal.shopthings.data.local.model.ProductAttributes
import com.vishal.shopthings.data.local.model.ProductImageUrl
import com.vishal.shopthings.data.local.model.ProductValues

object Converters {

    @TypeConverter
    fun fromProductImageUrlList(value: List<ProductImageUrl>?): String? {
        return Gson().toJson(value)
    }

    @TypeConverter
    fun toProductImageUrlList(value: String?): List<ProductImageUrl>? {
        val listType = object : TypeToken<List<ProductImageUrl>>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromProductAttributesList(value: List<ProductAttributes>?): String? {
        return Gson().toJson(value)
    }

    @TypeConverter
    fun toProductAttributesList(value: String?): List<ProductAttributes>? {
        val listType = object : TypeToken<List<ProductAttributes>>() {}.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromProductValuesList(value: List<ProductValues>?): String? {
        return Gson().toJson(value)
    }

    @TypeConverter
    fun toProductValuesList(value: String?): List<ProductValues>? {
        val listType = object : TypeToken<List<ProductValues>>() {}.type
        return Gson().fromJson(value, listType)
    }
}
