package com.vishal.shopthings.data.remote.api

import retrofit2.Response
import retrofit2.http.GET

interface ApiCalls {
    @GET(ApiConstants.API_APP_PRODUCTS)
    suspend fun apiCallForGetGetProducts(): Response<Any?>?

}