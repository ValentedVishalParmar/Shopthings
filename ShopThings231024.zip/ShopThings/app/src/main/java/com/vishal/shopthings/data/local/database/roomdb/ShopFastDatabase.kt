package com.vishal.shopthings.data.local.database.roomdb

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.vishal.shopthings.data.local.model.ProductData
import com.vishal.shopthings.util.Converters
import com.vishal.shopthings.util.ioThread
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@Database(entities = [ProductData::class], version = 1)
@TypeConverters(value = [Converters::class])
abstract class ProductDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDealsDao

    companion object {
        private const val NUMBER_OF_THREADS = 4
        val databaseWriteExecutor: ExecutorService = Executors.newFixedThreadPool(NUMBER_OF_THREADS)

        @Volatile
        private var INSTANCE: ProductDatabase? = null

        fun getDatabase(context: Context?): ProductDatabase? {

                if (INSTANCE == null) {
                    synchronized(ProductDatabase::class.java) {
                        if (INSTANCE == null) {

                              context?.let {
                             val intence =    Room.databaseBuilder(it, ProductDatabase::class.java, "shop_fast_db.db")
                                 .allowMainThreadQueries()
                                 .fallbackToDestructiveMigration()
                                 .addCallback(object : Callback() {

                                     override fun onCreate(db: SupportSQLiteDatabase) {
                                         super.onCreate(db)
                                         ioThread {
                                             initializeFreshDatabase()
                                         }
                                     }

                                 }).build()

                                 INSTANCE = intence
                             }
                        }
                    }
                }
                return INSTANCE
            }


        fun initializeFreshDatabase() {

        }
    }




}
