package com.vishal.shopthings.ui.activity

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.vishal.shopthings.R
import com.vishal.shopthings.ShopThings
import com.vishal.shopthings.databinding.ActivitySplashScreenBinding
import com.vishal.shopthings.ui.activity.product.ProductDealsListActivity
import com.vishal.shopthings.util.Constants
import com.vishal.shopthings.util.finishAndNavigateTo
import com.vishal.shopthings.util.navigateTo

class SplashScreenActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashScreenBinding
    private var handler: Handler? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashScreenBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)

        init()
        setSplashScreenData()
    }

    private fun init() {
        handler = Handler(Looper.getMainLooper())
        ShopThings.currentActivity = this@SplashScreenActivity
    }

    private fun setSplashScreenData() {
            handler?.postDelayed({
                finishAndNavigateTo(ProductDealsListActivity::class.java)
            }, Constants.SPLASH_SCREEN_DELAY * 1000)
    }


    override fun onDestroy() {
        super.onDestroy()
        if (this@SplashScreenActivity::binding.isInitialized) {
            handler = null
        }
    }
}