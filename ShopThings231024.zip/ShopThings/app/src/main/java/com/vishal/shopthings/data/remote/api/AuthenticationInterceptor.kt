package com.vishal.shopthings.data.remote.api

import android.content.Context
import android.util.Log
import com.vishal.shopthings.data.local.model.ApiResponse
import com.vishal.shopthings.util.request
import okhttp3.Interceptor
import okhttp3.Response


class AuthenticationInterceptor(val context: Context) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {

        val originalRequest = chain.request().newBuilder().build()

        val response = chain.proceed(originalRequest)
        return response
    }

}