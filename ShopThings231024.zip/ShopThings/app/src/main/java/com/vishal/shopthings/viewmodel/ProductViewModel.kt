package com.vishal.shopthings.viewmodel


import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vishal.shopthings.data.local.model.ApiResponse
import com.vishal.shopthings.data.local.model.ProductData
import com.vishal.shopthings.data.remote.api.Coroutines
import com.vishal.shopthings.data.remote.repository.ProductRepository
import com.vishal.shopthings.util.Constants.ERR_SOMETHING_WENT_WRONG


class ProductViewModel(private val repository: ProductRepository) : ViewModel() {

    var isListSortedToDescending: Boolean = true
    var currentPage = 0
    val itemsPerPage = 16
    private val setProductApiResponse = MutableLiveData<ApiResponse?>()
    val setInsertStatusProductListIntoDB = MutableLiveData<Boolean?>()
    var productListTotalIntoDB = 0
    var setAllDataOfProductFromDB = MutableLiveData<MutableList<ProductData>?>()
    private val setDatabaseException = MutableLiveData<ApiResponse?>()
    var isLoading = MutableLiveData<Boolean>().apply { value = false }

    val productDetails = MutableLiveData<ProductData?>()

    fun apiCallForGetProduct() {
        Coroutines.ioThenMain({ repository.apiCallForGetProducts() }, { response -> setProductApiResponse.value = response }, { error -> // Handle error, show an error message or log it
            setProductApiResponse.value = ApiResponse(message = ERR_SOMETHING_WENT_WRONG)
            Log.e("EXCEPTION", "Error occurred apiCallForProduct(): ${error.message}")
        })
    }

    fun insertProductList(productList: ArrayList<ProductData>) {
        Coroutines.ioThenMain({ repository.insertProductList(productList) }, { response ->
            setInsertStatusProductListIntoDB.value = response
        }, { error ->
            setDatabaseException.value = ApiResponse(message = ERR_SOMETHING_WENT_WRONG)
            Log.e("EXCEPTION", "Error occurred insertDocAiSummary(): ${error.message}")
        })
    }

    fun fetchAllDataOfProductListFromDB() {
        if (isLoading.value == true) return // Prevent multiple loads
        isLoading.value = true

        Coroutines.ioThenMain({
            isListSortedToDescending = !isListSortedToDescending

            repository.getPaginatedProducts(itemsPerPage, currentPage, isListSortedToDescending)
        }, { response ->
            setAllDataOfProductFromDB.value = response
            currentPage++
            isLoading.value = false
        }, { error ->
            setDatabaseException.value = ApiResponse(message = ERR_SOMETHING_WENT_WRONG)
            Log.e("EXCEPTION", "Error occurred fetchAllDataOfDocAISummaryFromDB(): ${error.message}")
        })
    }

    fun getProductCount() {

        Coroutines.ioThenMain({

            repository.getProductCount()
        }, { response ->
            if (response != null) {
                productListTotalIntoDB = response
            }

        }, { error ->
            setDatabaseException.value = ApiResponse(message = ERR_SOMETHING_WENT_WRONG)
            Log.e("EXCEPTION", "Error occurred fetchAllDataOfDocAISummaryFromDB(): ${error.message}")
        })
    }

    fun toggleSorting() {
        isListSortedToDescending = !isListSortedToDescending
        resetPagination()
        fetchAllDataOfProductListFromDB()
    }

    fun resetPagination() {
        currentPage = 0
        setAllDataOfProductFromDB.value?.clear()
    }

    fun fetchAllDataOfProductByIdFromDB(id: String  ) {
        Coroutines.ioThenMain({

            repository.getProductById(id)
        }, { response ->
            productDetails.value = response
        }, { error ->
            setDatabaseException.value = ApiResponse(message = ERR_SOMETHING_WENT_WRONG)
            Log.e("EXCEPTION", "Error occurred fetchAllDataOfDocAISummaryFromDB(): ${error.message}")
        })
    }

    val getProductApiResponse: MutableLiveData<ApiResponse?> get() = setProductApiResponse
    val getInsertionStatusOfProductFromDB: MutableLiveData<Boolean?> get() = setInsertStatusProductListIntoDB
    val getAllDataOfProductFromDB: MutableLiveData<MutableList<ProductData>?> get() = setAllDataOfProductFromDB
    val getDatabaseException: MutableLiveData<ApiResponse?> get() = setDatabaseException
    val getProductDetailsById: MutableLiveData<ProductData?> get() = productDetails
}