package com.vishal.shopthings

import com.vishal.shopthings.data.local.database.roomdb.ProductDatabase
import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import java.lang.reflect.Modifier

class ShopThings : Application(), Application.ActivityLifecycleCallbacks { companion object {

    var instance: ShopThings? = null
    var currentActivity: Activity? = null
    var dbObject: ProductDatabase? = null
    val gson: Gson
        get() {
            return GsonBuilder().excludeFieldsWithModifiers(Modifier.FINAL, Modifier.TRANSIENT, Modifier.STATIC).serializeNulls().setLenient().create()
        }

    fun executeTask(function: () -> Unit) {
        ProductDatabase.databaseWriteExecutor.execute {
            function()
        }
    }
}

    override fun onCreate() {
        super.onCreate()
        init()
    }

    private fun init() {
        instance = this@ShopThings
        registerActivityLifecycleCallbacks(this)
         try {
            // Initialize Room database safely with applicationContext
            val database = com.vishal.shopthings.data.local.database.roomdb.ProductDatabase.getDatabase(applicationContext)
            dbObject =database
            Log.d("ShopThings", "Database initialized successfully")
        } catch (e: Exception) {
            Log.e("ShopThings", "Error initializing database: ${e.message}")
        }

    }

    override fun onActivityCreated(p0: Activity, p1: Bundle?) {
        currentActivity = p0
    }

    override fun onActivityStarted(p0: Activity) {
        currentActivity = p0
    }

    override fun onActivityResumed(p0: Activity) {
        currentActivity = p0
    }

    override fun onActivityPaused(p0: Activity) {
    }

    override fun onActivityStopped(p0: Activity) {
    }

    override fun onActivitySaveInstanceState(p0: Activity, p1: Bundle) {

    }

    override fun onActivityDestroyed(p0: Activity) {

    }

}