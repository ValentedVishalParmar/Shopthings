package com.vishal.shopthings.data.remote.repository

import com.vishal.shopthings.ShopThings
import com.vishal.shopthings.data.local.model.ProductData
import com.vishal.shopthings.data.remote.api.ApiCalls
import com.vishal.shopthings.data.remote.api.ApiRequestResponse

class ProductRepository(private val apiRequest: ApiCalls?) : ApiRequestResponse() {
    private val productDealsDao = ShopThings.dbObject?.productDao()

    suspend fun apiCallForGetProducts() = apiRequest {
        apiRequest?.apiCallForGetGetProducts()
    }

    fun insertProductList(docAi: ArrayList<ProductData>): Boolean {
        var isInserted = false
        productDealsDao?.insertAll(docAi)?.let { long -> isInserted = long.isNotEmpty() }
        return isInserted

    }

     fun getPaginatedProducts(limit: Int, offset: Int, isAscending: Boolean): MutableList<ProductData> ?{
        return if (isAscending) {
            productDealsDao?.getAllDataOfProductAscendingOrder(limit, offset)
        } else {
            productDealsDao?.getAllDataOfProductDescendingOrder(limit, offset)
        }
    }

     fun getProductCount(): Int? {
        return productDealsDao?.getAllCount()
    }

    suspend fun getProductById(id: String): ProductData? {
        return productDealsDao?.getProductById(id)
    }


}