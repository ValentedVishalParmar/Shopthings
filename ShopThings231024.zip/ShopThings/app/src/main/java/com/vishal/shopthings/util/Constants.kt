package com.vishal.shopthings.util

object Constants {
    const val SPLASH_SCREEN_DELAY = 3L
    const val ERR_SOMETHING_WENT_WRONG = "Something went wrong!"
    const val serverApiDateTimeFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
    const val systemDateTimeFormat = "dd-MM-yyyy hh:mm:ss a"
    const val serverDateTimeFormat = "yyyy-MM-dd hh:mm:ss a"
}
object ExtraKey {
    const val EXTRA_MODEL = "object"
    const val EXTRA_PRODUCT_ID = "productID"
}