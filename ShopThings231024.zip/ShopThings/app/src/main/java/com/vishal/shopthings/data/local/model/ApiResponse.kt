package com.vishal.shopthings.data.local.model

import java.io.Serializable

data class ApiResponse(
    var statusCode: Int? = null,
    var data: Any? = null,
    var message: String? = null,
    var success: Boolean? = null,
) : Serializable
