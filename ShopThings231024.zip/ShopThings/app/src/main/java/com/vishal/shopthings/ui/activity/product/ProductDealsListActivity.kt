package com.vishal.shopthings.ui.activity.product

import android.Manifest
import android.app.AlertDialog
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.vishal.shopthings.R
import com.vishal.shopthings.data.local.model.ApiResponse
import com.vishal.shopthings.data.local.model.ProductData
import com.vishal.shopthings.data.remote.api.ApiCalls
import com.vishal.shopthings.data.remote.factory.ProductViewModelFactory
import com.vishal.shopthings.data.remote.repository.ProductRepository
import com.vishal.shopthings.databinding.ActivityProductDealsListBinding
import com.vishal.shopthings.interfaces.OnItemClickCListener
import com.vishal.shopthings.ui.adapter.ProductAdapter
import com.vishal.shopthings.util.ExtraKey
import com.vishal.shopthings.util.checkLocationPermission
import com.vishal.shopthings.util.handleOnBackPressed
import com.vishal.shopthings.util.hideLoader
import com.vishal.shopthings.util.isNetworkConnected
import com.vishal.shopthings.util.navigateTo
import com.vishal.shopthings.util.openAppSettings
import com.vishal.shopthings.util.request
import com.vishal.shopthings.util.setText
import com.vishal.shopthings.util.showLoader
import com.vishal.shopthings.util.toast
import com.vishal.shopthings.viewmodel.ProductViewModel
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ProductDealsListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProductDealsListBinding
    private lateinit var apiCall: ApiCalls
    private lateinit var productViewModel: ProductViewModel
    private var productAdapter: ProductAdapter? = null
    private lateinit var arrayPermission: Array<String>
    private var arrayProductData: ArrayList<ProductData>? = arrayListOf()
    private var isBackButtonPressedToExitFromApp = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductDealsListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        init()
        onClicks()
        manageBackPressEvent()
        setAdapter()
        setObserver()
        getProductCountFromDB()
    }

    private fun init() {
        arrayPermission = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        apiCall = request(ApiCalls::class.java)
        productViewModel = ViewModelProvider(this@ProductDealsListActivity, ProductViewModelFactory(ProductRepository(apiCall)))[ProductViewModel::class.java]

    }

    private fun getProductCountFromDB() {
        productViewModel.getProductCount()
    }

    private fun onClicks() {
        with(binding) {
            ivBack.setOnClickListener {
                manageBackPressEvent()
            }

            ivSort.setOnClickListener {
                if (arrayProductData?.isNullOrEmpty()?.not() == true) {
                    if (productViewModel.isListSortedToDescending) {
                        val ascendingList = arrayProductData?.sortedByDescending { it.Name }?.asReversed()?.toCollection(ArrayList())
                        productViewModel.isListSortedToDescending = false
                        productAdapter?.updateNewList(ascendingList)

                    } else {
                        val descendingList = arrayProductData?.sortedByDescending { it.Name }?.toCollection(ArrayList())
                        productViewModel.isListSortedToDescending = true
                        productAdapter?.updateNewList(descendingList)
                    }
                }
            }

            ivMenu.setOnClickListener {
                toast("This feature Under development")
            }
            rvProducts.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    val layoutManager = recyclerView.layoutManager as GridLayoutManager
                    val totalItemCount = layoutManager.itemCount
                    val lastVisibleItemPosition = layoutManager.findLastVisibleItemPosition()

                    // If we are at the bottom of the list and not currently loading more items
                    if (totalItemCount <= (lastVisibleItemPosition + 1) && !productViewModel.isLoading.value!!) {
                        if (arrayProductData?.size?.let { size -> size < productViewModel.productListTotalIntoDB } == true) {
                            productViewModel.fetchAllDataOfProductListFromDB()

                        } else {
                            productViewModel.isLoading.value = false
                        }
                    }
                }
            })
        }
    }

    private fun getLocationPermission() {
        requestLocationPermission()
    }

    private fun requestLocationPermission() {
        launchLocationPermission.launch(arrayPermission)
    }

    private fun setTotalCount() {
        setText(binding.tvProductCount, getString(R.string.total_product_count, arrayProductData?.size))
    }

    private fun setAdapter() {
        binding.rvProducts.apply {
            layoutManager = GridLayoutManager(this@ProductDealsListActivity, 2, GridLayoutManager.VERTICAL, false)
            productAdapter = ProductAdapter(this@ProductDealsListActivity, arrayProductData ?: arrayListOf(), object : OnItemClickCListener {
                override fun onClickItem(any: Any?) {
                    super.onClickItem(any)
                    if (any is Int) {
                        navigateTo(ProductDetailsActivity::class.java, {
                            this.putString(ExtraKey.EXTRA_PRODUCT_ID, arrayProductData?.get(any)?.databaseId.toString())
                        })
                    }
                }

                override fun onProductAdd(position: Int) {
                    super.onProductAdd(position)
                    if (position >= 0) {
                        arrayProductData?.get(position)?.StockQuantity?.plus(1)
                        productAdapter?.updateNewList(arrayProductData)
                    }
                }

                override fun onProductRemove(position: Int) {
                    super.onProductRemove(position)
                    if (position >= 0) {
                        if (arrayProductData?.get(position)?.StockQuantity != 0) {
                            arrayProductData?.get(position)?.StockQuantity?.minus(1)
                            productAdapter?.updateNewList(arrayProductData)
                        }
                    }
                }
            })
            adapter = productAdapter
        }
    }

    private fun apiCallForGetProducts() {
        if (isValidForApiCall()) {
            showLoader()
            productViewModel.apiCallForGetProduct()

        } else {
            Toast.makeText(this@ProductDealsListActivity, getString(R.string.err_no_internet), Toast.LENGTH_SHORT).show()
        }
    }

    private fun setObserver() {
        productViewModel.getProductApiResponse.observe(this@ProductDealsListActivity) { apiResponse ->
            hideLoader()
            val arrayListOfProductFromApi: ArrayList<ProductData> = Gson().fromJson(Gson().toJson(apiResponse?.data), object : TypeToken<ArrayList<ProductData>>() {}.type)
            if (arrayListOfProductFromApi.isNullOrEmpty().not()) {
                productViewModel.insertProductList(arrayListOfProductFromApi)
                productViewModel.getProductApiResponse.value = ApiResponse()
            }

            Log.e("arrayListOfProduct>>>", "setObserver: ${Gson().toJson(arrayProductData)}")
        }

        productViewModel.getDatabaseException.observe(this) { databaseException ->
            hideLoader()
            toast(databaseException?.message)
        }

        productViewModel.getInsertionStatusOfProductFromDB.observe(this) { isSuccess ->
            Log.e("getInsertionStatusOfProductFromDB>>>", "setObserver: $isSuccess")
            productViewModel.getProductApiResponse.postValue(ApiResponse())
            if (isSuccess == true) {
                fetchAllDataOfProductFromDB()
            }
        }

        productViewModel.getAllDataOfProductFromDB.observe(this) { arrayListDocAISummary ->
            val newListOfDocAISummary = ArrayList<ProductData>()

            arrayListDocAISummary?.forEach { docAISummary ->
                newListOfDocAISummary.add(docAISummary)
            }

            manageArrayListOfUploadedDocuments(newListOfDocAISummary)
        }

        productViewModel.isLoading.observe(this) { isLoading ->
            if (isLoading) {
                showLoader()
            } else {
                hideLoader()
            }
        }
    }

    private fun manageArrayListOfUploadedDocuments(arrayListUploadedDocuments: ArrayList<ProductData>?) {
        arrayListUploadedDocuments?.takeIf { it.isNotEmpty() }?.let { documentList ->
            if (productAdapter == null) {
                arrayProductData?.clear()
                arrayProductData?.addAll(documentList)
                setAdapter()

            } else {
                productAdapter?.appendProducts(documentList)
            }
            setTotalCount()

        } ?: {
            if (checkLocationPermission()) {
                fetchAllDataOfProductFromDB()

            } else {
                requestLocationPermission()
            }
        }
    }

    private fun isValidForApiCall(): Boolean {
        return !isNetworkConnected.not()
    }

    private fun fetchAllDataOfProductFromDB() {
        productViewModel.fetchAllDataOfProductListFromDB()

    }

    private val launchLocationPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        var allGranted = false

        permissions.entries.forEach {
            val isGranted = it.value
            allGranted = isGranted
        }

        if (allGranted) {
            apiCallForGetProducts()

        } else {
            if (checkLocationPermission().not()) {
                showLocationDialog()
            }

        }
    }

    private fun showLocationDialog() {
        val msg: String = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            getString(R.string.text_location_permission)

        } else {
            getString(R.string.text_location_permission_all_time)
        }

        AlertDialog.Builder(this@ProductDealsListActivity).setTitle(R.string.title_location_permission).setMessage(msg).setPositiveButton(getString(R.string.open_setting)) { _, _ ->
            openAppSettings()
        }.create().show()
    }

    private fun manageBackPressEvent() {
        handleOnBackPressed {
            askForTapBackButtonAgainToExitApp()
        }
    }

    @OptIn(DelicateCoroutinesApi::class)
    private fun askForTapBackButtonAgainToExitApp() {
        if (isBackButtonPressedToExitFromApp) {
            finishAffinity()
        }

        isBackButtonPressedToExitFromApp = true

        GlobalScope.launch {
            delay(2000)
            isBackButtonPressedToExitFromApp = false
        }
    }

    override fun onResume() {
        super.onResume()
        if (checkLocationPermission().not()) {
            getLocationPermission()

        } else {
            fetchAllDataOfProductFromDB()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        productViewModel.getProductApiResponse.postValue(null)
    }
}