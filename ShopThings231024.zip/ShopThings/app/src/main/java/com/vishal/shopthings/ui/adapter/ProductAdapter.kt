package com.vishal.shopthings.ui.adapter


import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.net.toUri
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.RecyclerView
import com.vishal.shopthings.R
import com.vishal.shopthings.data.local.model.ProductData
import com.vishal.shopthings.databinding.ItemProductListBinding
import com.vishal.shopthings.interfaces.OnItemClickCListener
import com.vishal.shopthings.util.FormattedAmount
import com.vishal.shopthings.util.loadImage
import com.vishal.shopthings.util.setText
import com.vishal.shopthings.util.strike
import com.vishal.shopthings.util.viewGone
import com.vishal.shopthings.util.viewVisible

class ProductAdapter(private var context: AppCompatActivity?, private var arrayListProduct: ArrayList<ProductData>,  private val onItemClickCListener: OnItemClickCListener) : RecyclerView.Adapter<ProductAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(DataBindingUtil.inflate(LayoutInflater.from(parent.context), R.layout.item_product_list, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (position >= 0 && position < arrayListProduct.size) {
            val productData = arrayListProduct[position]
            holder.bind(productData)
        }
    }

    override fun getItemCount(): Int {
        return arrayListProduct.size
    }

    inner class ViewHolder(private val binding: ItemProductListBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(productData: ProductData?) {
            with(binding) {

                binding.productData = productData
                executePendingBindings()

                // product image
                if (productData?.ProductPictures.isNullOrEmpty().not()) {
                    if (productData?.ProductPictures?.get(0)?.PictureUrl.isNullOrEmpty().not()) {
                        loadImage(ivProductLogo, productData?.ProductPictures?.get(0)?.PictureUrl, AppCompatResources.getDrawable(ivProductLogo.context, R.drawable.ic_placeholder_product))

                    } else {
                        loadImage(ivProductLogo, productData?.ProductPictures?.get(0)?.PictureUrl,  AppCompatResources.getDrawable(ivProductLogo.context, R.drawable.ic_placeholder_product))
                    }

                } else {
                    loadImage(ivProductLogo, null,  AppCompatResources.getDrawable(ivProductLogo.context, R.drawable.ic_placeholder_product))

                }

                // product name
                setText(tvProductName, productData?.Name ?: "-")

                //product description
                if (productData?.ShortDescription.isNullOrEmpty().not()) {
                    setText(tvProductDescription, productData?.ShortDescription)
                    viewVisible(tvProductDescription)

                } else {
                    viewGone(tvProductDescription)
                }

                // old price
                setText(tvProductOldPrice, tvProductOldPrice.context.getString(R.string.old_product_price, productData?.DiscountAmount.FormattedAmount()))
                tvProductOldPrice.strike = true

                // new price
                setText(tvProductNewPrice, tvProductNewPrice.context.getString(R.string.new_product_price, productData?.Price.FormattedAmount()))
                setText(tvProductCount, productData?.StockQuantity?.toString())

                if (adapterPosition % 2 == 0 ) {
                    loadImage(ivProductLogo, null,  AppCompatResources.getDrawable(ivProductLogo.context, R.drawable.ic_veg))
                    setText(tvProductWeight, "500gm")

                } else {
                    setText(tvProductWeight, "1kg")
                    loadImage(ivProductLogo,null,  AppCompatResources.getDrawable(ivProductLogo.context, R.drawable.ic_non_veg))

                }

                binding.root.setOnClickListener {
                    onItemClickCListener.onClickItem(adapterPosition)
                }

                fabAddProduct.setOnClickListener {
                  viewVisible(fabAddProductByOne)
                  viewVisible(fabRemoveProductByOne)
                    viewVisible(tvProductCount)
                    viewGone(fabAddProduct)
                }

                fabAddProductByOne.setOnClickListener {
                   onItemClickCListener.onProductAdd(adapterPosition)
                }

                fabRemoveProductByOne.setOnClickListener {
                    onItemClickCListener.onProductRemove(adapterPosition)
                }
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun updateNewList(newList: ArrayList<ProductData>?) {
        newList?.let { list ->
            this.arrayListProduct = list
            notifyDataSetChanged()
        }
    }

    fun appendProducts(newProducts: List<ProductData>) {
        val startPosition = arrayListProduct.size
         arrayListProduct.addAll( newProducts)
        notifyItemRangeInserted(startPosition, newProducts.size)
    }
}
