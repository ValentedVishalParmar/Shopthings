plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.vishal.shopthings"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vishal.shopthings"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        vectorDrawables {
            useSupportLibrary = true
        }

    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isDebuggable = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            buildConfigField("String", "BASE_URL","\"https://baseball-test.shopfast.com/api/v1/\"")
        }
        
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    buildFeatures{
        dataBinding = true
        buildConfig = true
        viewBinding = true
    }


    kotlinOptions {
        jvmTarget = "11"
    }

    // KSP configuration

        ksp {
            arg("enabled", "true") // Pass KSP argument
        }

}

dependencies {

    // Android core libs
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)

    // NETWORKING
    implementation(libs.retrofit)
    implementation(libs.gson)

    // KOTLIN COROUTINES, MVVM , LIFE CYCLE AND LIVE DATA AND VIEW MODEL
    implementation(libs.coroutines.core)
    implementation(libs.coroutines.android)
    implementation(libs.coroutines.test)
    implementation(libs.lifecycle.extension)
    implementation(libs.lifecycleruntime)
    implementation(libs.livedata)
    implementation(libs.viewmodel)
    implementation(libs.viewmodel.savedstate)

    // ROOM DATABASE AND MIGRATIONS


    // KSP for Room (instead of kapt)
    implementation(libs.room.persistance)
    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    implementation(libs.ksp.symbol.processing.api)
    ksp(libs.room.compiler)

    // GLIDE FOR IMAGE LOADING
    implementation(libs.glide)

    // LOGGING AND INTERCEPTION
    implementation(platform(libs.okhttp3Bom))
    implementation(libs.okhttp3)
    implementation(libs.okhttp3.logging)


}
